void main() {

//this is  coment
void main() {
TRISA=0x00;
PORTA=0X00;

TRISB=0xFF;
PORTB=0x00;

while(1){

 if(RB7_bit==1)
 {

RA0_bit=1;
RA1_bit=0;
RA2_bit=0;
delay_ms(500);
RA0_bit=0;
RA1_bit=1;
RA2_bit=0;
delay_ms(500);
RA0_bit=0;
RA1_bit=0;
RA2_bit=1;
delay_ms(500);
}
else{
RA0_bit=0;
RA1_bit=0;
RA1_bit=0;
}
}

}