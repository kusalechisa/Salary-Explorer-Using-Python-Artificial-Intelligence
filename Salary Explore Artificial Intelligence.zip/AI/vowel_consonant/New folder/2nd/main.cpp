%{
#include <stdio.h>
%}
%%
if|else|while|int|switch|for|char {printf("keyword");}
[a-z]([a-z]|[0-9])* {printf("identifier");}
[0-9]* {printf("number");}
.* {printf("invalid");}
\n     {return 0;}
%%
int yywrap()
{ }
main()
{
yylex();
return 0;
}

