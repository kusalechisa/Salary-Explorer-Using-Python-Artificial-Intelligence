import streamlit as st
import pickle
import numpy as np



def show_about():
    st.image("haramaya4.jpg", width=700)
    st.title("       HARAMAYA UNIVERSITY")

    st.write("""# COLLEGE OF COMPUTING AND INFORMATICS""")
    st.write("""## DEPARTMENT OF SOFTWARE ENGINEERING""")
    st.write("""### ARTIFICIAL INTELLIGENCE ASSIGNMENT""")
    st.write("""#### NAME OF STUDENTS:----------ID""")
    st.write("""##### YADUMA LECHISA------------2817/13""")
    st.write("""##### KENGITAN KEBETO----------1596/13""")
    st.write("""##### LEMESA KASIM----------------1680/13""")
    st.write("""##### GAZU LEMI----------------------1260/13""")
    st.write("""##### ELIAS ASEFA--------------------0917/13""")